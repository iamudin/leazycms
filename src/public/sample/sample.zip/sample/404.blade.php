<div class="container">
   <div class="row">
	   <div class="col-lg-12">
		   	<nav aria-label="breadcrumb">
  <ol class="breadcrumb">
    <li class="breadcrumb-item"><a href="/">Beranda</a></li>

    <li class="breadcrumb-item active"  aria-current="page" >Halaman Tidak Ditemukan</li>
  </ol>
</nav>
		    
		   <div class="py-5 text-center">
			   <h1>Upss!</h1>
		   <h3>Halaman yang anda akses saat ini tidak tersedia atau sudah dihapus.</h3>
	   </div>
   </div>
	</div>
</div>