<?php
if(!function_exists('somefunction')){
function somefunction(){
	return true;
}
	}
