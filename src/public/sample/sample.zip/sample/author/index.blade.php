<h1>You Script Here</h1>
@foreach($author as $row)
{{$row->name}}
@endforeach